﻿using System.Collections.Generic;
using System.Threading.Tasks;
using MateuszApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace TaskAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TaskController : ControllerBase
    {
        private readonly Generators _generators;
        private readonly ILogger<TaskController> _logger;
        private List<Task> _summaries;

        public TaskController(ILogger<TaskController> logger)
        {
            _generators = new Generators();
            _logger = logger;
        }

        [HttpGet]
        [Route("/Connect")]
        public async Task<IActionResult> Connect()
        {
            _summaries = _generators.GenerateRandomTasks(1000);

            return Ok();
        }

        [HttpGet]
        public async Task<IActionResult> GetAllAsync()
        {
            return Ok(_summaries);
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> GetAsync(int id)
        {
            if (id >= _summaries.Count || id < 0)
            {
                return UnprocessableEntity();
            }
            
            var response = _summaries[id];
            return Ok(response);
        }

        [HttpPost]
        public async Task<IActionResult> PostAsync(TaskDto taskDto)
        {
            var task = new Task()
            {
                Id = _summaries.Count,
                Title = taskDto.Title,
                Description = taskDto.Description,
                Completed = taskDto.Completed
            };

            _summaries.Add(task);
            return Accepted();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutAsync(int id, TaskDto taskDto)
        {
            if (id >= _summaries.Count || id < 0)
            {
                return UnprocessableEntity();
            }

            var task = new Task()
            {
                Id = id,
                Title = taskDto.Title,
                Description = taskDto.Description,
                Completed = taskDto.Completed
            };

            _summaries[id] = task;
            return Ok();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAsync(int id)
        {
            if (id >= _summaries.Count || id < 0)
            {
                return UnprocessableEntity();
            }
            
            _summaries.RemoveAt(id);
            return Ok();
        }
    }
}